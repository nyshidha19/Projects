from flask import Flask, render_template, request, jsonify
import os
import wave
import pyaudio
import numpy as np
import librosa
import tensorflow as tf
import joblib
import threading
import subprocess
from email.mime.text import MIMEText
import smtplib
import random
from dotenv import load_dotenv
import datetime

app = Flask(__name__)

# Load environment variables
load_dotenv()
EMAIL_USER = os.getenv("EMAIL_USER")
EMAIL_PASS = os.getenv("EMAIL_PASS")
EMAIL_RECEIVER = os.getenv("EMAIL_RECEIVER")

# OTP Storage (temporary in-memory)
otp_storage = {}

# Load the trained model, label encoder, and scaler
try:
    model = tf.keras.models.load_model("voice_recognition_cnn_model.h5")
    encoder = joblib.load("label_encoder.pkl")
    scaler = joblib.load("scaler.pkl")
    print("Model, Encoder, and Scaler loaded successfully!")
    print("Training Labels:", encoder.classes_)
except Exception as e:
    print(f"Error loading model, encoder, or scaler: {e}")

VOICE_DIR = "voice_samples"
os.makedirs(VOICE_DIR, exist_ok=True)

FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 44100
CHUNK = 1024
RECORD_SECONDS = 6
MAX_PAD_LEN = 50


def retrain_model():
    try:
        subprocess.run(["python", "feature_extraction.py"], check=True)
        subprocess.run(["python", "train_model.py"], check=True)
        global model, encoder, scaler
        model = tf.keras.models.load_model("voice_recognition_cnn_model.h5")
        encoder = joblib.load("label_encoder.pkl")
        scaler = joblib.load("scaler.pkl")
    except Exception as e:
        print(f"Retraining error: {e}")


def record_audio(filename):
    try:
        audio = pyaudio.PyAudio()
        stream = audio.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=CHUNK)
        frames = [stream.read(CHUNK) for _ in range(0, int(RATE / CHUNK * RECORD_SECONDS))]
        stream.stop_stream()
        stream.close()
        audio.terminate()
        with wave.open(filename, "wb") as wf:
            wf.setnchannels(CHANNELS)
            wf.setsampwidth(audio.get_sample_size(FORMAT))
            wf.setframerate(RATE)
            wf.writeframes(b"".join(frames))
    except Exception as e:
        print(f"Audio recording error: {e}")


def extract_features(file_path):
    try:
        y, sr = librosa.load(file_path, sr=RATE)
        mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40)
        mfccs = librosa.util.fix_length(mfccs, size=MAX_PAD_LEN, axis=1).flatten()
        return scaler.transform([mfccs])
    except Exception as e:
        print(f"Feature extraction error: {e}")
        return None


def send_otp_email():
    otp = str(random.randint(100000, 999999))
    otp_storage['otp'] = otp
    otp_storage['timestamp'] = datetime.datetime.now()
    msg = MIMEText(f"Unauthorized access detected.\nOTP to approve access: {otp}\nValid for 90 seconds only!")
    msg['Subject'] = 'Unauthorized Access - OTP Required'
    msg['From'] = EMAIL_USER
    msg['To'] = EMAIL_RECEIVER
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(EMAIL_USER, EMAIL_PASS)
        server.send_message(msg)
        server.quit()
    except Exception as e:
        print(f"Email error: {e}")


def authenticate_user(audio_path):
    try:
        features = extract_features(audio_path)
        if features is None:
            return "Error extracting features ❌"
        prediction = model.predict(features)
        max_prob = np.max(prediction[0])
        predicted_label = np.argmax(prediction[0])
        if max_prob < 0.8:
            send_otp_email()
            return "Unauthorized User ❌ - OTP Sent to Admin"
        speaker_name = encoder.inverse_transform([predicted_label])[0]
        return "User Verified ✅"
    except Exception as e:
        print(f"Authentication error: {e}")
        return "Authentication Error ❌"


@app.route("/")
def home():
    users = os.listdir(VOICE_DIR) if os.path.exists(VOICE_DIR) else []
    return render_template("index.html", users=users)


@app.route("/register", methods=["POST"])
def register():
    try:
        username = request.form["username"].strip()
        if not username:
            return jsonify({"message": "Invalid username!"}), 400
        user_path = os.path.join(VOICE_DIR, username)
        if os.path.exists(user_path):
            return jsonify({"message": f"User {username} already exists!"})
        os.makedirs(user_path)
        for i in range(10):
            record_audio(os.path.join(user_path, f"{username}_{i+1}.wav"))
        threading.Thread(target=retrain_model).start()
        return jsonify({"message": f"User {username} registered. Model retraining started."})
    except Exception as e:
        return jsonify({"message": f"Error: {e}"}), 500


@app.route("/record_auth", methods=["POST"])
def record_auth():
    try:
        audio_path = "test_voice.wav"
        record_audio(audio_path)
        result = authenticate_user(audio_path)
        return jsonify({"message": result})
    except Exception as e:
        return jsonify({"message": f"Error: {e}"}), 500


@app.route("/verify_otp", methods=["POST"])
def verify_otp():
    user_otp = request.json.get("otp")
    now = datetime.datetime.now()
    otp_time = otp_storage.get("timestamp")

    if otp_time and (now - otp_time).total_seconds() <= 90:
        if user_otp == otp_storage.get("otp"):
            otp_storage.clear()
            return jsonify({"message": "Access Granted ✅ by Admin"})
        else:
            return jsonify({"message": "Invalid OTP ❌"}), 401
    else:
        otp_storage.clear()
        return jsonify({"message": "OTP Expired ⏳ Access Denied ❌"}), 403


if __name__ == "__main__":
    app.run(debug=True)